var user = {
    username: 'new_user',
    password: '123456789'
}

function login() {
   var username = document.getElementById('username').value;
   var password = document.getElementById('password').value;
   console.log(username,password);
   if (username ===user.username && password === user.password) {
       var loginCont = document.getElementById('login-container');
       loginCont.style.display = 'none';

   } else {
       var errorMsg = document.querySelector('.err-msg');
       errorMsg.style.display = 'block';
   } 

}